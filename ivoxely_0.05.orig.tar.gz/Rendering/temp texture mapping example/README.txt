Provided is a vs2010 solution file and a makefile
MAKE SURE CAPS LOCK IS OFF
CONTROLS:
W: 			 	in
S: 				zoom out
A: 				pan left
D: 				pan right
mouse_left: 	pitch and roll (drag up and side to side)
mouse_right: 	yaw
F:				return camera to default state

Requires OPENGL 3.3. Made by Brian Cozzens.
