#!/bin/sh
export CXX=/usr/bin/clang++
export CC=/usr/bin/clang
./compileRun.sh
