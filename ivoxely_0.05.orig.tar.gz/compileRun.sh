#!/bin/sh
cmake .
make
./OpenGL_program
