#!/bin/sh
rm -rf CMakeFiles/
rm CMakeCache.txt cmake_install.cmake Makefile OpenGL_program
